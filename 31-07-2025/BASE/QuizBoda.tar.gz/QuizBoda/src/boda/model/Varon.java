package boda.model;

public class Varon extends Persona{
    public Varon(String nombre){
        super(nombre);
    }
}
