package boda.model;

public class Mujer extends Persona {
    public Mujer(String nombre) {
        super(nombre);
    }
}
