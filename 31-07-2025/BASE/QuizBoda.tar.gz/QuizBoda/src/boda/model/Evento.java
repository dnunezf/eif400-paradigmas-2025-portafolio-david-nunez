// Enum para los eventos (JURAMENTO, FIRMA, etc.)

package boda.model;

public enum Evento {
    JURAMENTO,
    FIRMA,
    BRINDIS,
    VALS
}
